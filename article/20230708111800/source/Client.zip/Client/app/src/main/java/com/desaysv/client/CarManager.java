package com.desaysv.client;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.RemoteException;
import android.provider.SyncStateContract;
import android.util.Log;

import com.desaysv.carservice.ICallBack;
import com.desaysv.carservice.ICar;

import java.util.Arrays;

public class CarManager {

    private static final String TAG = "CarManager";

    private static final String PACKAGE_NAME = "com.desaysv.carservice";
    private static final String SERVICE_NAME = "com.desaysv.carservice.CarService";
    private final Context mContext;
    private ICar mCar;
    private ICallBack mCallback;

    public CarManager(Context context) {
        mContext = context.getApplicationContext();
        bindService();
    }

    private void bindService() {
        Intent service = new Intent();
        service.setClassName(PACKAGE_NAME, SERVICE_NAME);
        mContext.bindService(service, conn, Context.BIND_AUTO_CREATE);
    }

    private ServiceConnection conn = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            Log.e(TAG, "onServiceConnected");
            try {
                service.linkToDeath(deathRecipient, 0);

            } catch (RemoteException e) {
                e.printStackTrace();
            }

            mCar = ICar.Stub.asInterface(service);


            try {
                registerCallBack();
                sendValues();
                getValues();
            } catch (RemoteException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            Log.e(TAG, "onServiceDisconnected");
        }
    };

    /**
     * Binder有意外退出通知的机制：Link-To-Death
     */
    private IBinder.DeathRecipient deathRecipient = new IBinder.DeathRecipient() {
        @Override
        public void binderDied() {
            Log.d(TAG, "binder died. name:" + Thread.currentThread().getName());
            bindService();
        }
    };

    public void registerCallBack() throws RemoteException {
        mCallback = new ICallBack.Stub() {
            @Override
            public void onChange(int moduleId, int signalID, int[] data) throws RemoteException {
                Log.d(TAG, "moduleId : " + moduleId + ", signalID : " + signalID + ", data : " + Arrays.toString(data));
            }
        };
        mCar.registerCallBack(mCallback);
    }

    public void unRegisterCallBack() throws RemoteException {
        mCar.unRegisterCallBack(mCallback);
    }

    public void getValues() throws RemoteException {
        int[] value = mCar.getValues(1, 2);
        Log.d(TAG, "getValues : " + Arrays.toString(value));
    }

    public void sendValues() throws RemoteException {
        mCar.sendValues(100, 200, new int[]{900, 20, 360});
    }

}
