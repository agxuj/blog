package com.desaysv.carservice;

import android.app.Application;
import android.content.Intent;

public class AppContext extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        startForegroundService(new Intent(this, CarService.class));
    }
}
