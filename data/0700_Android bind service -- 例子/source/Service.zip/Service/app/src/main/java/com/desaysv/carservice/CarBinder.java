package com.desaysv.carservice;


import android.os.Handler;
import android.os.Looper;
import android.os.RemoteCallbackList;
import android.os.RemoteException;
import android.util.Log;

import java.util.Arrays;

/**
 * 应用层解析车身SPI消息Binder
 *
 * @author uidq1913
 */
public class CarBinder extends ICar.Stub {

    public static final String TAG = "CarBinder";

    public final RemoteCallbackList<ICallBack> listeners = new RemoteCallbackList<>();


    public void onDestroy() {

    }

    Handler handler = new Handler(Looper.getMainLooper());

    {
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                int len = listeners.beginBroadcast();

                for (int i = 0; i < len; i++) {
                    ICallBack callBack = listeners.getBroadcastItem(i);
                    try {
                        callBack.onChange(1,2,new int[]{3,2,1});
                    } catch (RemoteException e) {
                        e.printStackTrace();
                    }
                }

                listeners.finishBroadcast();
                handler.postDelayed(this, 5000);
            }
        }, 5000);
    }

    @Override
    public void registerCallBack(ICallBack callback) {
        listeners.register(callback);
    }

    @Override
    public void unRegisterCallBack(ICallBack callback) {
        listeners.unregister(callback);
    }

    @Override
    public int[] getValues(int funcID, int cmdID) {
        return new int[]{1, 2, 3};
    }

    @Override
    public void sendValues(int funcID, int cmdID, int[] values) {
        Log.d(TAG, "sendValues values : " + Arrays.toString(values));
    }

}
